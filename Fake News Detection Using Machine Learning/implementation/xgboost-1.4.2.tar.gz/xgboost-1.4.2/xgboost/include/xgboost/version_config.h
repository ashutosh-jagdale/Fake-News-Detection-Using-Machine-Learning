/*!
 * Copyright 2019 XGBoost contributors
 */
#ifndef XGBOOST_VERSION_CONFIG_H_
#define XGBOOST_VERSION_CONFIG_H_

#define XGBOOST_VER_MAJOR 1
#define XGBOOST_VER_MINOR 4
#define XGBOOST_VER_PATCH 2

#endif  // XGBOOST_VERSION_CONFIG_H_
